1. 安装ruby (http://dl.bintray.com/oneclick/rubyinstaller/)
2. 安装Redis的Ruby驱动redis-xxxx.gem   gem install --local redis-xxxx.gem   (https://rubygems.org/gems/redis/)
3. 安装集群脚本redis-trib  (https://raw.githubusercontent.com/MSOpenTech/redis/3.0/src/redis-trib.rb)
4. 启动所有redis
5. 执行集群构建脚本 ruby redis-trib.rb create --replicas 1 127.0.0.1:6379 127.0.0.1:6380 127.0.0.1:6381 127.0.0.1:6382 127.0.0.1:6383 127.0.0.1:6384
 （--replicas 1 表示每个主数据库拥有从数据库个数为1。master节点不能少于3个，所以我们用了6个redis）
6. redis-cli -c -h 127.0.0.1 -p 6379   输入cluster info可以从客户端的查看集群的信息

